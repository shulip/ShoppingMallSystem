#!/usr/bin/env python 
# -*- coding:utf-8 -*-

from .Ui_ProprietorWindow import *